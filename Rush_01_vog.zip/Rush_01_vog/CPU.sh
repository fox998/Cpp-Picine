top -l 1 | grep Processes: |  cut -d' ' -f2
top -l 1 | grep Processes: |  cut -d' ' -f4
top -l 1 | grep Processes: |  cut -d' ' -f6
top -l 1 | grep Processes: |  cut -d' ' -f8
top -l 1 | grep 'CPU usage:' |  cut -d' ' -f3
top -l 1 | grep 'CPU usage:' |  cut -d' ' -f5
top -l 1 | grep 'CPU usage:' |  cut -d' ' -f7