date +"%d/%m/%Y"
date +"%H.%M.%S"