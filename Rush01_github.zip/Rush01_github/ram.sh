top -l 1 | grep PhysMem | cut -d' ' -f2
top -l 1 | grep PhysMem | cut -d' ' -f6