hostname -f
echo "$USER"
sw_vers -productVersion