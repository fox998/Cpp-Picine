top -l 1 | grep 'packets:' |  cut -d' ' -f3
top -l 1 | grep 'packets:' |  cut -d' ' -f5