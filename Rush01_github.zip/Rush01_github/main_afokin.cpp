
#include    "GraphicalMode.hpp"

int     main()
{
    GraphicalMode   g;

    g.loop();
}
